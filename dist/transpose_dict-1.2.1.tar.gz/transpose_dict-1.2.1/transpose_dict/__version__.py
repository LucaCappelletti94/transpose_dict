"""Current version of the transpose-dict package."""
__version__ = "1.2.1"
